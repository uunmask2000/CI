<html>
<head>
        <title></title>
</head>
<body>
        <h1></h1>
         <h1><?php echo $key;?></h1>
        
<?php echo form_open_multipart('User/do_update');?>         
User name:
<input type="text" name="name" size="20"  value="<?php echo $user_name;?>" /><br>
User email:
<input type="email" name="email" size="20" value="<?php echo $user_email;?>" /><br>
User password:
<input type="password" name="psw" value="<?php echo $user_password;?>" ><br>
<input type="hidden" name="hidden_id" value="<?php echo $id;?>" >
<input type="submit" value="submit" />

</form>

</body>
</html>