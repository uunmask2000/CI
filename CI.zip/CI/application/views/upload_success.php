 <html>
<head>
<title>Upload Form</title>
</head>
<body>

<h3>Your file was successfully uploaded!</h3>

<ul>
<?php foreach ($upload_data as $item => $value):?>
<li><?php echo $item;?>: <?php echo $value;?></li>
<?php endforeach; ?>
</ul>

<p><?php echo anchor('upload', 'Upload Another File!'); ?></p>
<?php
print_r($upload_data) ;
$p_file_name =  $upload_data['file_name'] ;
///echo base_url();
echo img('uploads/'.$p_file_name); 


$url = "http://192.168.0.66/CI/index.php/upload";
echo "<script type='text/javascript'>";
///echo "window.location.href='$url'";
?>
setTimeout("location.href='<?=$url;?>'",5000);
<?php
echo "</script>"; 
?>

</body>
</html>