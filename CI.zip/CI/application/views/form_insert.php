<html>
<head>
<title>Upload Form</title>
</head>
<body>

<?php echo $error;?>

<?php echo form_open_multipart('User/do_insert');?>
User name:
<input type="text" name="name" size="20" /><br>
User email:
<input type="email" name="email" size="20" /><br>
User password:
<input type="password" name="psw"><br>
<input type="hidden" name="hidden_id" value="<?= rand(1,20000);?>">
<input type="submit" value="submit" />

</form>

</body>
</html> 
