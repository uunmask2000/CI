<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<html>
  <head>
    <title>Simple_view</title>
	  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.13/css/jquery.dataTables.min.css">
	  <script src="//code.jquery.com/jquery-1.12.4.js"></script>
	  <script src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>
	  <style>
	.button {
	background-color: #4CAF50; /* Green */
	border: none;
	color: white;
	padding: 15px 32px;
	text-align: center;
	text-decoration: none;
	display: inline-block;
	font-size: 16px;
	margin: 4px 2px;
	cursor: pointer;
	}

	.button2 {background-color: #008CBA;} /* Blue */
	.button3 {background-color: #f44336;} /* Red */ 
	.button4 {background-color: #e7e7e7; color: black;} /* Gray */ 
	.button5 {background-color: #555555;} /* Black */
	</style>
    </head>
  <body>
  <?php
	   // $segments = 'User_insert'; 
	   // echo site_url($segments);
	    //button button2   button button2  button button  button button5
	    echo anchor('User/User_insert', 'User_insert' , array(  'class' => 'button button2' ,'title="User_insert" ' ) );
  ?>
	  <table id="example" class="display" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>id</th>
                <th>user_name</th>
                <th>user_email</th>
                <th>user_password</th>
				 <th>fix</th>
				 <th>del</th>
            </tr>
        </thead>
        <tfoot>
            <tr>
               <th>id</th>
                <th>user_name</th>
                <th>user_email</th>
                <th>user_password</th>
				<th>fix</th>
				<th>del</th>
            </tr>
        </tfoot>
        <tbody>
			<?php
			
			$sql_txt = "SELECT * FROM user_login";
			$query = $this->db->query($sql_txt);
			$Result =  $query->result() ;
			foreach ($Result as $row)
					{
					  $user_name =   $row->user_name;
					  $user_email =   $row->user_email;
					  $user_password =   $row->user_password;
					  $key =   $row->id;
			
						      echo '<tr>
						      <td>'.$key.'</td>
						      <td>'.$user_name.'</td>
						      <td>'.$user_email.'</td>
						      <td>'.$user_password.'</td>';
							?>
							<td><?php  echo anchor('User/User_fix/'.$key, 'User_fix' , array(  'class' => 'button button3' ,'title => "User_fix" ' ) );?></td>
							<td><?php  echo anchor('User/User_del/'.$key, 'User_del' , array(  'class' => 'button button4', 'class' => 'button button4' ,'title => "User_del" ','onclick'=>"return ConfirmDialog();" ) );?></td>
							<?php
							echo '</tr>';
					}
			?>
			
        </tbody>
    </table>
	    <script>
	    function ConfirmDialog() {
  var x=confirm("Are you sure to delete record?")
  if (x) {
    return true;
  } else {
    return false;
  }
}
			$(document).ready(function() {
						$('#example').DataTable({
						"columns": [
											{ "data": "id" },
											{ "data": "title" },
											{ "data": "slug" },
											{ "data": "text" },
											{ "data": "fix" },
											{ "data": "del" }
										]
						});
						} );
						
	    </script>	
		  
  </body>
</html>