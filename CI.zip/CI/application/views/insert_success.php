 <html>
<head>
<title>Upload Form</title>
</head>
<body>

<h3>Your insert was successfully uploaded!</h3>
<?php
$url = "http://192.168.0.66/CI/index.php/View_user";
echo "<script type='text/javascript'>";
///echo "window.location.href='$url'";
?>
setTimeout("location.href='<?=$url;?>'",5000);
<?php
echo "</script>"; 
?>


</body>
</html> 
