 <?php
defined('BASEPATH') OR exit('No direct script access allowed');
class View_user extends CI_Controller {
			  public function __construct()
			  {
			      parent::__construct();
			      $this->load->helper(array('form', 'url'));
			      $this->load->helper('html');
			  }
			  public function index()
			  {
			  $this->load->view('view_form_user');

			  }
	
}
