 
 <?php

class User extends CI_Controller {

	 

        public function __construct()
        {
                parent::__construct();
                $this->load->helper(array('form', 'url','html'));
                $this->load->library('form_validation');
              
        }
         public function index()
        {
                $this->load->view('form_insert', array('error' => ' ' ));
        }
        
        
        public function User_insert()
	{
	      $this->load->view('form_insert', array('error' => ' ' ));
	}
        
        
	public function do_insert()
	{
		
			     $name = trim($this->input->post("name"));			   
			    $email = trim($this->input->post("email"));
			    $psw = trim($this->input->post("psw"));
			    $hidden_id = trim($this->input->post("hidden_id"));
			    $name  = preg_replace('/\s(?=)/', '', $name);
			    $email = preg_replace('/\s(?=)/', '', $email);
			    $psw   = preg_replace('/\s(?=)/', '', $psw);

			    $data = array(
			    'user_name' =>  $name,
			    'user_email' =>  $email,
			    'user_password' =>  $psw
			    );
			//   $query = $this->db->query('');
			if(empty($name))
			{
			  echo '<script type="text/javascript">alert("NULL了!");window.history.back();</script>';
			  exit();
			}
			$query = $this->db->query("SELECT * FROM user_login WHERE  user_name = '$name'");
			if ($query->num_rows() != 0)
			{			
				echo '<script type="text/javascript">alert("帳號重覆了!");window.history.back();</script>';
			}else{
			
			//echo 'A2';
			$this->db->insert('user_login', $data);
			$this->load->view('insert_success');
			}

	  
	
		// 產生： INSERT INTO mytable (title, name, date) VALUES ('My title', 'My name', 'My date')
	}
	
	public function User_del()
	{
	     // $this->load->view('form_insert', array('error' => ' ' ));
	     /// echo 'A';
			  if ($this->uri->segment(3) === FALSE)
			  {
			  $key = 0;
			  }
			  else
			  {
			  $key = $this->uri->segment(3);
			  }
			  $sql_rxt = " DELETE FROM user_login WHERE id = '$key' ";
			      if ($this->db->simple_query($sql_rxt))
			      {
			                //echo "Success!";
			         header('Location: http://192.168.0.66/CI/index.php/View_user');
			      }
			      else
			      {
			                   ////echo "Query failed!";
			      }	
			  
	}
	
	public function User_fix()
	{
		      if ($this->uri->segment(3) === FALSE)
		      {
		      $key = 0;
		      }
		      else
		      {
		      $key = $this->uri->segment(3);
		      }
		      
			     // $data['title'] = "My Real Title";
			   //   $data['heading'] = "My Real Heading";
			      $data['key'] = $key ;
			      
			  $query = $this->db->query('SELECT * FROM user_login where id ='.$key);

			  foreach ($query->result_array() as $row)
			  {
				    $data['id'] = $row['id'];
				    $data['user_name'] = $row['user_name'];
				    $data['user_email'] = $row['user_email'];
				    $data['user_password'] = $row['user_password'];
				    
				     // echo $row['id'];
				     // echo $row['user_name'];
				    //  echo $row['user_email'];
				    //  echo $row['user_password'];
			  }
			

                  $this->load->view('form_update', $data);
	}
	
	
	
	public function do_update()
	{
		
			    $name = trim($this->input->post("name"));			   
			    $email = trim($this->input->post("email"));
			    $psw = trim($this->input->post("psw"));
			    $hidden_id = trim($this->input->post("hidden_id"));
			    $name  = preg_replace('/\s(?=)/', '', $name);
			    $email = preg_replace('/\s(?=)/', '', $email);
			    $psw   = preg_replace('/\s(?=)/', '', $psw);
			 
			  $data = array(
			  'user_name' =>  $name,
			    'user_email' =>  $email,
			    'user_password' =>  $psw
			  );
			  
		     
			  
		    $this->db->where('id', $hidden_id);
		    $this->db->update('user_login', $data);	
		    $affected_rows = $this->db->affected_rows();   //檢查sql 影響數值
		   echo $str = $this->db->last_query();
		   echo $affected_rows  ;
		    if($affected_rows != 0)
		    {
		          //echo 'SQL有影響' ;
		            header('Location: http://192.168.0.66/CI/index.php/View_user');
		    }else{
		          ///echo 'SQL不影響' ;
		            header('Location: http://192.168.0.66/CI/index.php/View_user');
		    }
		    
		    //ECHO $str ;
		    
			    
	}		    


}
?>
